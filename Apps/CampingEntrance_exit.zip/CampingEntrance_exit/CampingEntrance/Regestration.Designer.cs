﻿namespace CampingEntrance
{
    partial class Regestration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbRegestration = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.btnCheckAvailability = new System.Windows.Forms.Button();
            this.BtnEventRegistration = new System.Windows.Forms.Button();
            this.pbSpot9 = new System.Windows.Forms.PictureBox();
            this.pbSpot6 = new System.Windows.Forms.PictureBox();
            this.pbSpot8 = new System.Windows.Forms.PictureBox();
            this.pbSpot7 = new System.Windows.Forms.PictureBox();
            this.pbSpot2 = new System.Windows.Forms.PictureBox();
            this.pbSpot1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pbSpot5 = new System.Windows.Forms.PictureBox();
            this.pbSpot3 = new System.Windows.Forms.PictureBox();
            this.pbSpot4 = new System.Windows.Forms.PictureBox();
            this.lblUser1Name = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.lblUser2Name = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblUser6Name = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lblUser3Name = new System.Windows.Forms.Label();
            this.lblUser5Name = new System.Windows.Forms.Label();
            this.lblUser4Name = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbSpot9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSpot6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSpot8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSpot7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSpot2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSpot1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSpot5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSpot3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSpot4)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.groupBox1.Controls.Add(this.lbRegestration);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.btnCheckAvailability);
            this.groupBox1.Controls.Add(this.BtnEventRegistration);
            this.groupBox1.Controls.Add(this.pbSpot9);
            this.groupBox1.Controls.Add(this.pbSpot6);
            this.groupBox1.Controls.Add(this.pbSpot8);
            this.groupBox1.Controls.Add(this.pbSpot7);
            this.groupBox1.Controls.Add(this.pbSpot2);
            this.groupBox1.Controls.Add(this.pbSpot1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.pbSpot5);
            this.groupBox1.Controls.Add(this.pbSpot3);
            this.groupBox1.Controls.Add(this.pbSpot4);
            this.groupBox1.Controls.Add(this.lblUser1Name);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.lblUser2Name);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.lblUser6Name);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.lblUser3Name);
            this.groupBox1.Controls.Add(this.lblUser5Name);
            this.groupBox1.Controls.Add(this.lblUser4Name);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Location = new System.Drawing.Point(-1, 93);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(668, 661);
            this.groupBox1.TabIndex = 88;
            this.groupBox1.TabStop = false;
            // 
            // lbRegestration
            // 
            this.lbRegestration.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.lbRegestration.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lbRegestration.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbRegestration.ForeColor = System.Drawing.Color.Black;
            this.lbRegestration.Location = new System.Drawing.Point(3, 593);
            this.lbRegestration.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbRegestration.Name = "lbRegestration";
            this.lbRegestration.Size = new System.Drawing.Size(662, 65);
            this.lbRegestration.TabIndex = 81;
            this.lbRegestration.Text = "Registration Status";
            this.lbRegestration.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.label2.Location = new System.Drawing.Point(1, 0);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(667, 12);
            this.label2.TabIndex = 80;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Black;
            this.label22.Location = new System.Drawing.Point(274, 302);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(88, 32);
            this.label22.TabIndex = 79;
            this.label22.Text = "Spots";
            // 
            // btnCheckAvailability
            // 
            this.btnCheckAvailability.BackColor = System.Drawing.Color.White;
            this.btnCheckAvailability.BackgroundImage = global::CampingEntrance.Properties.Resources.button_check_spots_availability;
            this.btnCheckAvailability.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCheckAvailability.Location = new System.Drawing.Point(365, 531);
            this.btnCheckAvailability.Name = "btnCheckAvailability";
            this.btnCheckAvailability.Size = new System.Drawing.Size(276, 59);
            this.btnCheckAvailability.TabIndex = 78;
            this.btnCheckAvailability.UseVisualStyleBackColor = false;
            this.btnCheckAvailability.Click += new System.EventHandler(this.btnCheckAvailability_Click_1);
            // 
            // BtnEventRegistration
            // 
            this.BtnEventRegistration.BackColor = System.Drawing.Color.White;
            this.BtnEventRegistration.BackgroundImage = global::CampingEntrance.Properties.Resources.button_register_here;
            this.BtnEventRegistration.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnEventRegistration.Location = new System.Drawing.Point(7, 531);
            this.BtnEventRegistration.Name = "BtnEventRegistration";
            this.BtnEventRegistration.Size = new System.Drawing.Size(252, 59);
            this.BtnEventRegistration.TabIndex = 54;
            this.BtnEventRegistration.UseVisualStyleBackColor = false;
            this.BtnEventRegistration.Click += new System.EventHandler(this.BtnEventRegistration_Click_1);
            // 
            // pbSpot9
            // 
            this.pbSpot9.Image = global::CampingEntrance.Properties.Resources.button__8_;
            this.pbSpot9.Location = new System.Drawing.Point(479, 437);
            this.pbSpot9.Name = "pbSpot9";
            this.pbSpot9.Size = new System.Drawing.Size(83, 70);
            this.pbSpot9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSpot9.TabIndex = 77;
            this.pbSpot9.TabStop = false;
            this.pbSpot9.Click += new System.EventHandler(this.pbSpot9_Click_1);
            // 
            // pbSpot6
            // 
            this.pbSpot6.Image = global::CampingEntrance.Properties.Resources.button__5_;
            this.pbSpot6.Location = new System.Drawing.Point(74, 437);
            this.pbSpot6.Name = "pbSpot6";
            this.pbSpot6.Size = new System.Drawing.Size(83, 70);
            this.pbSpot6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSpot6.TabIndex = 74;
            this.pbSpot6.TabStop = false;
            this.pbSpot6.Click += new System.EventHandler(this.pbSpot6_Click_1);
            // 
            // pbSpot8
            // 
            this.pbSpot8.Image = global::CampingEntrance.Properties.Resources.button__7_;
            this.pbSpot8.Location = new System.Drawing.Point(345, 437);
            this.pbSpot8.Name = "pbSpot8";
            this.pbSpot8.Size = new System.Drawing.Size(83, 70);
            this.pbSpot8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSpot8.TabIndex = 76;
            this.pbSpot8.TabStop = false;
            this.pbSpot8.Click += new System.EventHandler(this.pbSpot8_Click_1);
            // 
            // pbSpot7
            // 
            this.pbSpot7.Image = global::CampingEntrance.Properties.Resources.button__6_1;
            this.pbSpot7.Location = new System.Drawing.Point(218, 437);
            this.pbSpot7.Name = "pbSpot7";
            this.pbSpot7.Size = new System.Drawing.Size(83, 70);
            this.pbSpot7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSpot7.TabIndex = 75;
            this.pbSpot7.TabStop = false;
            this.pbSpot7.Click += new System.EventHandler(this.pbSpot7_Click_1);
            // 
            // pbSpot2
            // 
            this.pbSpot2.Image = global::CampingEntrance.Properties.Resources.button__1_;
            this.pbSpot2.Location = new System.Drawing.Point(154, 344);
            this.pbSpot2.Name = "pbSpot2";
            this.pbSpot2.Size = new System.Drawing.Size(83, 70);
            this.pbSpot2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSpot2.TabIndex = 70;
            this.pbSpot2.TabStop = false;
            this.pbSpot2.Click += new System.EventHandler(this.pbSpot2_Click_1);
            // 
            // pbSpot1
            // 
            this.pbSpot1.Image = global::CampingEntrance.Properties.Resources.button1;
            this.pbSpot1.Location = new System.Drawing.Point(18, 344);
            this.pbSpot1.Name = "pbSpot1";
            this.pbSpot1.Size = new System.Drawing.Size(84, 70);
            this.pbSpot1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSpot1.TabIndex = 69;
            this.pbSpot1.TabStop = false;
            this.pbSpot1.Click += new System.EventHandler(this.pbSpot1_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(13, 34);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 24);
            this.label1.TabIndex = 54;
            this.label1.Text = "Visitor 1 name";
            // 
            // pbSpot5
            // 
            this.pbSpot5.Image = global::CampingEntrance.Properties.Resources.button__4_;
            this.pbSpot5.Location = new System.Drawing.Point(538, 344);
            this.pbSpot5.Name = "pbSpot5";
            this.pbSpot5.Size = new System.Drawing.Size(83, 70);
            this.pbSpot5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSpot5.TabIndex = 73;
            this.pbSpot5.TabStop = false;
            this.pbSpot5.Click += new System.EventHandler(this.pbSpot5_Click_1);
            // 
            // pbSpot3
            // 
            this.pbSpot3.Image = global::CampingEntrance.Properties.Resources.button__2_;
            this.pbSpot3.Location = new System.Drawing.Point(280, 344);
            this.pbSpot3.Name = "pbSpot3";
            this.pbSpot3.Size = new System.Drawing.Size(83, 70);
            this.pbSpot3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSpot3.TabIndex = 71;
            this.pbSpot3.TabStop = false;
            this.pbSpot3.Click += new System.EventHandler(this.pbSpot3_Click_1);
            // 
            // pbSpot4
            // 
            this.pbSpot4.Image = global::CampingEntrance.Properties.Resources.button__3_;
            this.pbSpot4.Location = new System.Drawing.Point(409, 344);
            this.pbSpot4.Name = "pbSpot4";
            this.pbSpot4.Size = new System.Drawing.Size(83, 70);
            this.pbSpot4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSpot4.TabIndex = 72;
            this.pbSpot4.TabStop = false;
            this.pbSpot4.Click += new System.EventHandler(this.pbSpot4_Click);
            // 
            // lblUser1Name
            // 
            this.lblUser1Name.AutoSize = true;
            this.lblUser1Name.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.lblUser1Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUser1Name.ForeColor = System.Drawing.Color.Black;
            this.lblUser1Name.Location = new System.Drawing.Point(276, 34);
            this.lblUser1Name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUser1Name.Name = "lblUser1Name";
            this.lblUser1Name.Size = new System.Drawing.Size(61, 24);
            this.lblUser1Name.TabIndex = 63;
            this.lblUser1Name.Text = "Name";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(13, 82);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(129, 24);
            this.label9.TabIndex = 55;
            this.label9.Text = "Visitor 2 name";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(13, 260);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(129, 24);
            this.label16.TabIndex = 62;
            this.label16.Text = "Visitor 6 name";
            // 
            // lblUser2Name
            // 
            this.lblUser2Name.AutoSize = true;
            this.lblUser2Name.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.lblUser2Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUser2Name.ForeColor = System.Drawing.Color.Black;
            this.lblUser2Name.Location = new System.Drawing.Point(276, 82);
            this.lblUser2Name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUser2Name.Name = "lblUser2Name";
            this.lblUser2Name.Size = new System.Drawing.Size(61, 24);
            this.lblUser2Name.TabIndex = 64;
            this.lblUser2Name.Text = "Name";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(13, 124);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(129, 24);
            this.label11.TabIndex = 56;
            this.label11.Text = "Visitor 3 name";
            // 
            // lblUser6Name
            // 
            this.lblUser6Name.AutoSize = true;
            this.lblUser6Name.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.lblUser6Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUser6Name.ForeColor = System.Drawing.Color.Black;
            this.lblUser6Name.Location = new System.Drawing.Point(276, 260);
            this.lblUser6Name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUser6Name.Name = "lblUser6Name";
            this.lblUser6Name.Size = new System.Drawing.Size(61, 24);
            this.lblUser6Name.TabIndex = 68;
            this.lblUser6Name.Text = "Name";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(14, 167);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(129, 24);
            this.label14.TabIndex = 60;
            this.label14.Text = "Visitor 4 name";
            // 
            // lblUser3Name
            // 
            this.lblUser3Name.AutoSize = true;
            this.lblUser3Name.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.lblUser3Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUser3Name.ForeColor = System.Drawing.Color.Black;
            this.lblUser3Name.Location = new System.Drawing.Point(276, 124);
            this.lblUser3Name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUser3Name.Name = "lblUser3Name";
            this.lblUser3Name.Size = new System.Drawing.Size(61, 24);
            this.lblUser3Name.TabIndex = 65;
            this.lblUser3Name.Text = "Name";
            // 
            // lblUser5Name
            // 
            this.lblUser5Name.AutoSize = true;
            this.lblUser5Name.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.lblUser5Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUser5Name.ForeColor = System.Drawing.Color.Black;
            this.lblUser5Name.Location = new System.Drawing.Point(276, 214);
            this.lblUser5Name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUser5Name.Name = "lblUser5Name";
            this.lblUser5Name.Size = new System.Drawing.Size(61, 24);
            this.lblUser5Name.TabIndex = 66;
            this.lblUser5Name.Text = "Name";
            // 
            // lblUser4Name
            // 
            this.lblUser4Name.AutoSize = true;
            this.lblUser4Name.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.lblUser4Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUser4Name.ForeColor = System.Drawing.Color.Black;
            this.lblUser4Name.Location = new System.Drawing.Point(276, 167);
            this.lblUser4Name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUser4Name.Name = "lblUser4Name";
            this.lblUser4Name.Size = new System.Drawing.Size(61, 24);
            this.lblUser4Name.TabIndex = 67;
            this.lblUser4Name.Text = "Name";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(14, 214);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(129, 24);
            this.label15.TabIndex = 61;
            this.label15.Text = "Visitor 5 name";
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.BackColor = System.Drawing.Color.White;
            this.lblStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatus.ForeColor = System.Drawing.Color.Black;
            this.lblStatus.Location = new System.Drawing.Point(381, 35);
            this.lblStatus.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(94, 24);
            this.lblStatus.TabIndex = 87;
            this.lblStatus.Text = "Rfid status";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(12, 35);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(206, 24);
            this.label3.TabIndex = 89;
            this.label3.Text = "Please Scan Rfid here!!";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.BackgroundImage = global::CampingEntrance.Properties.Resources.Rfid__2_1;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.Location = new System.Drawing.Point(225, 15);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(112, 75);
            this.button2.TabIndex = 80;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Regestration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(667, 753);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lblStatus);
            this.Name = "Regestration";
            this.Text = "Regestration";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbSpot9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSpot6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSpot8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSpot7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSpot2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSpot1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSpot5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSpot3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSpot4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblUser1Name;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lblUser2Name;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblUser6Name;
        private System.Windows.Forms.Label lblUser3Name;
        private System.Windows.Forms.Label lblUser5Name;
        private System.Windows.Forms.Label lblUser4Name;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.PictureBox pbSpot1;
        private System.Windows.Forms.PictureBox pbSpot2;
        private System.Windows.Forms.PictureBox pbSpot6;
        private System.Windows.Forms.PictureBox pbSpot9;
        private System.Windows.Forms.PictureBox pbSpot7;
        private System.Windows.Forms.PictureBox pbSpot8;
        private System.Windows.Forms.PictureBox pbSpot3;
        private System.Windows.Forms.PictureBox pbSpot5;
        private System.Windows.Forms.PictureBox pbSpot4;
        private System.Windows.Forms.Button BtnEventRegistration;
        private System.Windows.Forms.Button btnCheckAvailability;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbRegestration;
    }
}